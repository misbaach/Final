package Tugas2;

/**
 *
 * @author Misbach
 */
class Kpop extends Singer {
    @Override
    public void perform() {
        System.out.println(" Beraksi di atas panggung, bernyanyi dengan merdu, dan ngedance");
    }
}
