package Tugas2;

/**
 *
 * @author Misbach
 */
class Musician {
    public void perform() {
        System.out.println(" Beraksi di atas panggung");
    }
}